#include <iostream>    // Entrada y salida estándar
#include <vector>      // Contenedores dinámicos de datos
#include <queue>       // Colas
#include <stack>       // Pilas
#include <algorithm>   // Funciones útiles para operaciones en contenedores
#include <cmath>       // Funciones matemáticas comunes
#include <cstring>     // Funciones para manejar cadenas de caracteres
#include <string>     // Funciones para manejar cadenas de caracteres
#include <set>         // Conjuntos ordenados
#include <map>         // Tablas de hash
#include <unordered_set>  // Conjuntos desordenados
#include <unordered_map>  // Tablas de hash desordenadas
#include <bitset>      // Conjunto de bits
#include <tuple> 	// Tuplas
#include <cassert> // Assert
using namespace std;

int main()
{
    return 0;
}

/*
#define MAX LLONG_MAX // INT_MAX
#define MIN LLONG_MIN // INT_MIN

const lf PI = acos(-1);//3.141592653589793;

//MOD
inline ll add(ll a, ll b, const ll& mod) { return a+b >= mod ? a+b-mod : a+b; }
inline ll sbt(ll a, ll b, const ll& mod) { return a-b < 0 ? a-b+mod : a-b; }
inline ll mul(ll a, ll b, const ll& mod) { return 1ll*a*b%mod; }

// Random Integer number
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
ll random(ll a, ll b) {return uniform_int_distribution<ll> (a,b) (rng);}

// Input with archive
#ifdef LOCALNZN
    freopen("input.txt", "r", stdin); 
    freopen("output.txt", "w", stdout);  
#else
    #define endl '\n'
#endif
*/

/*
// Hi! :)
#include<bits/stdc++.h>
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(0)
#define precise(ans,k) fixed << setprecision(k) << ans //k digit
using namespace std;

int main()
{   
    FAST;
    return 0;
}
// Refrain from coding until you are sure that your algorithm is both correct and fast enough !!!
*/