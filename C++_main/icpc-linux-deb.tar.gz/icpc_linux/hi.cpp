// Hi! :)
#include<bits/stdc++.h>
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(0)
#define precise(ans,k) fixed << setprecision(k) << ans //k digit
using namespace std;

int main()
{
    FAST;
    return 0;
}
// Refrain from coding until you are sure that your algorithm is both correct and fast enough !!!
// timeout 5s ./hi <in >out