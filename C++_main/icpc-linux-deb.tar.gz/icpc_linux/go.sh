#!/bin/bash

# Check if a filename is provided as an argument
if [ $# -ne 2 ]; then
    echo "Usage: $0 <program_name> [limit]"
    exit 1
fi

program_name="$1"
limit=$2

name_with_extension="${program_name}.cpp"
# name_without_extension="${program%.*}"

# Compile the program
g++ -DLOCALNZN -std=c++17 -g -O2 -Wall -Wextra -Wshadow -Wconversion -Wfloat-equal -Wduplicated-cond -Wlogical-op -D_GLIBCXX_DEBUG -o "$program_name" "$name_with_extension"

# Check if compilation was successful
if [ $? -eq 0 ]; then
    # Execute the compiled program
    timeout "$limit"s "./$program_name" <in
    if [ $? -eq 124 ]; then
        echo "TLE: Execution took too long."
    else
        echo "Program executed within time limit."
    fi
else
    echo "Error compiling $program_name"
fi

# README
# chmod +x go.sh
# ./go.sh hi 1