#!/bin/bash

# Usage: ./stress.sh <gen> <my_program> <brute_force> [limit]
if [ $# -lt 3 ]; then
    echo "Usage: $0 <gen> <my_program> <brute_force> [limit]"
    exit 1
fi

gen="$1"
my_program="$2"
brute_force="$3"
limit=$4

# Compile all executables
echo "Compiling source files..."
if ! g++ -DLOCALNZN -std=c++17 -o "$gen" "$gen".cpp; then
    echo "Compilation failed for $gen. Exiting."
    exit 1
fi

if ! g++ -DLOCALNZN -std=c++17 -o "$my_program" "$my_program".cpp; then
    echo "Compilation failed for $my_program. Exiting."
    exit 1
fi

if ! g++ -DLOCALNZN -std=c++17 -o "$brute_force" "$brute_force".cpp; then
    echo "Compilation failed for $brute_force. Exiting."
    exit 1
fi

# A and B are executables you want to compare
# gen takes int as command line arg. Usage: 'sh stress.sh'

echo "Start stress test.."
for ((i = 1; i <= limit; ++i)); do
    # echo "Test $i"

    # Generate input
    ./gen $i > inp

    # Execute A and B, redirecting input from inp and output to out1 and out2
    timeout 5s ./$my_program < inp > out1_$my_program
    
    # Check if timeout occurred
    if [ $? -eq 124 ]; then
        echo "Test $i"
        echo "TLE $my_program"
        echo "Execution took too long. Terminating."
        exit 
    fi

    timeout 5s ./$brute_force < inp > out2_$brute_force

    # Check if timeout occurred
    if [ $? -eq 124 ]; then
        echo "Test $i"
        echo "TLE $brute_force" 
        echo "Execution took too long. Terminating."
        exit
    fi

    # Compare output of A and B
    # differences=$(diff -w out1_$my_program out2_$brute_force)
    differences=$(diff -y --suppress-common-lines out1_$my_program out2_$brute_force)
    if [ -n "$differences" ]; then
        # my_program | brute_force
        echo "Test $i"
        echo "WA" 
        echo "$differences"
        exit
    fi
done

if [ -z "$differences" ]; then
    echo "AC"
fi

# README
# chmod +x stress.sh
# ./stress.sh gen hi bf 10