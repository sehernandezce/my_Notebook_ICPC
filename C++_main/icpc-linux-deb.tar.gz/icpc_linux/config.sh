#!/bin/bash

echo "apt Update..."
sudo apt update

# Install dependencies
echo "Installing Visual Studio Code..."
sudo apt install code -y  # Install Visual Studio Code on Debian-based systems

echo "Installing GCC..."
sudo apt install gcc -y  # Install GCC on Debian-based systems

# Config script
echo "Config script..."
script_go="go"
chmod +x "$script_go.sh"  # Grant execution permissions to the script

# Set up the 'go' alias
echo "# Set up icp_compile_and_run" >> ~/.bashrc
echo "alias go='$(pwd)/$script_go.sh'" >> ~/.bashrc
source ~/.bashrc # Execute => manual

# Add to PATH
export PATH="$PATH:$(pwd)"  # Add current directory to the PATH

echo "Setup completed successfully."


# README
# chmod +x config.sh
# ./config.sh