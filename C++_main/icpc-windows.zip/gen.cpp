#include<bits/stdc++.h>
using namespace std;

#define precise(ans,k) fixed << setprecision(k) << ans //k digit
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(0)
#define endl '\n'

typedef long long ll;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

ll random(ll a, ll b) {return uniform_int_distribution<ll> (a,b) (rng);}

// [0.0, 1.0) => random_double(0.0, 1.0)
double random_double(double a, double b) {
    uniform_real_distribution<double> distribution(a, b);
    return distribution(rng);
}

// random_word(8)
string random_word(int length) {
    string word;
    uniform_int_distribution<int> distribution('a', 'z');
    for (int i = 0; i < length; ++i) {
        word += distribution(rng);
    }
    return word;
}

int main()
{   
    FAST;
    return 0;
}