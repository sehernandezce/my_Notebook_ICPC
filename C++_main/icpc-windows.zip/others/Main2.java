import java.util.*;
import java.io.*;

public class Main2{
    public static void main(String[] args) {
        
        
        BufferedReader lecture;
        // lecture = new BufferedReader(new InputStreamReader(System.in));
        
        // BufferedReader lecture;
        // try {
        //     FileReader in;
        //     in = new FileReader("input.txt");
        //     lecture = new BufferedReader(in);
        // } catch (Exception e) {
        //     return;
        // }
        
        BufferedWriter writer;
        writer = new BufferedWriter(new OutputStreamWriter(System.out));

        // BufferedWriter writer;
        // try {
        //     FileWriter out;
        //     out = new FileWriter("output.txt");
        //     writer = new BufferedWriter(out);
        // } catch (IOException e) {
        //     writer = null;
        //     return;
        // }


        BufferedReader bufferedReader;
        FileReader in;
        try {
            in = new FileReader("input.txt");
        } catch (Exception e) {
            in = null;
        }
        bufferedReader = new BufferedReader(in);

        BufferedWriter bufferedWriter;
        FileWriter out;
        try {
            out = new FileWriter("output.txt");
        } catch (IOException e) {
            out = null;
        }
        bufferedWriter = new BufferedWriter(out);

        try {
            
            
        } catch (Exception e) {
            return;
        }
    }
}